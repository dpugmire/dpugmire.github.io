import os
import time
import yaml
import re
import json
import requests
from pathlib import Path

from scholarly import scholarly, ProxyGenerator

# ---- Config ----
SCHOLAR_ID = os.getenv("SCHOLAR_ID", "FmxWGN0AAAAJ")  # David's Scholar ID by default
VENUE_MAP_FILE = Path("_data/venue_map.yml")
YAML_OUT = Path("_data/publications.yml")
BIB_OUT = Path("assets/publications.bib")

# Optional: set SERPAPI_API_KEY as a repo secret for reliability
SERPAPI_API_KEY = os.getenv("SERPAPI_API_KEY", "").strip()

# ---- Proxy setup for reliability ----
def maybe_setup_proxy():
    if SERPAPI_API_KEY:
        pg = ProxyGenerator()
        if pg.SerpAPI(api_key=SERPAPI_API_KEY):
            scholarly.use_proxy(pg)
            print("Using SerpAPI proxy via scholarly")
            return
    # Fallback: no proxy. scholarly may still work but can be rate-limited.
    print("No SerpAPI key provided; proceeding without proxy")

# ---- Venue override map ----
def load_venue_overrides():
    if VENUE_MAP_FILE.exists():
        data = yaml.safe_load(VENUE_MAP_FILE.read_text()) or {}
        return data.get("overrides", [])
    return []

def classify_type(venue: str, overrides):
    v = (venue or "").lower()
    for rule in overrides:
        if rule.get("match") and rule["match"].lower() in v:
            t = rule.get("type", "").lower().strip()
            if t in {"journal", "conference", "bookchapter"}:
                return t
    # heuristics
    if any(k in v for k in ["journal", "transactions", "letters"]):
        return "journal"
    if any(k in v for k in ["conference", "symposium", "workshop", "proceedings"]):
        return "conference"
    if any(k in v for k in ["book", "chapter", "springer", "wiley handbook"]):
        return "bookchapter"
    return "conference"  # safe default for many CS venues

# ---- Crossref DOI lookup by title/year ----
def crossref_doi_lookup(title: str, year: str | int):
    try:
        if not title:
            return None
        params = {"query.bibliographic": title, "rows": 1}
        if year:
            params["filter"] = f"from-pub-date:{year}-01-01,until-pub-date:{year}-12-31"
        r = requests.get("https://api.crossref.org/works", params=params, timeout=15)
        if r.ok:
            items = r.json().get("message", {}).get("items", [])
            if items:
                return items[0].get("DOI")
    except Exception as e:
        print("Crossref lookup failed:", e)
    return None

# ---- Helpers ----
def norm_year(y):
    try:
        return int(str(y)[:4])
    except Exception:
        return None

def clean_authors(s):
    # scholarly returns 'A A Author and B B Author'
    return s.replace(" and ", ", ")

def unique_key(title, year):
    t = re.sub(r"\W+", "", (title or "").lower())
    return f"{t}_{year}"

def fetch_and_build():
    overrides = load_venue_overrides()
    maybe_setup_proxy()

    author = scholarly.search_author_id(SCHOLAR_ID)
    author = scholarly.fill(author, sections=["publications"])

    yaml_records = []
    bib_entries = {}
    seen = set()

    # Fill each pub
    for p in author.get("publications", []):
        try:
            scholarly.fill(p)  # enrich with bib
            bib = p.get("bib", {})
            title = bib.get("title", "").strip()
            year = norm_year(bib.get("pub_year"))
            authors = clean_authors(bib.get("author", ""))
            venue = bib.get("venue", "")
            url = bib.get("url")
            eprint = bib.get("eprint")

            if not title or not year:
                continue

            key = unique_key(title, year)
            if key in seen:
                continue
            seen.add(key)

            # classify
            ptype = classify_type(venue, overrides)

            # DOI (Crossref lookup, lightweight & cached by Crossref CDN)
            doi = crossref_doi_lookup(title, year)

            rec = {
                "title": title,
                "authors": authors,
                "venue": venue,
                "year": year,
                "type": ptype,
            }
            if doi:
                rec["doi"] = doi
            if url:
                rec["url"] = url
            elif eprint:
                rec["url"] = eprint

            yaml_records.append(rec)

            # BibTeX string from scholarly; keep as-is
            try:
                bibtex_str = scholarly.bibtex(p)
                bib_entries[key] = bibtex_str.strip()
            except Exception as e:
                print("bibtex export failed for:", title, e)
        except Exception as e:
            print("Failed to process a publication:", e)
            time.sleep(2)

    # Sort YAML by year desc then title
    yaml_records.sort(key=lambda r: (r.get("year", 0), r.get("title", "")), reverse=True)

    # Write to temp files, then replace only if changed
    YAML_OUT.parent.mkdir(parents=True, exist_ok=True)
    tmp_yaml = YAML_OUT.with_suffix(".yml.tmp")
    tmp_yaml.write_text(yaml.dump(yaml_records, sort_keys=False, allow_unicode=True))

    old_yaml = YAML_OUT.read_text() if YAML_OUT.exists() else ""
    new_yaml = tmp_yaml.read_text()
    if new_yaml != old_yaml:
        tmp_yaml.replace(YAML_OUT)
        print("Updated", YAML_OUT)
    else:
        tmp_yaml.unlink(missing_ok=True)
        print("No changes for", YAML_OUT)

    BIB_OUT.parent.mkdir(parents=True, exist_ok=True)
    tmp_bib = BIB_OUT.with_suffix(".bib.tmp")
    tmp_bib.write_text("\n\n".join(bib_entries[k] for k in sorted(bib_entries.keys())))

    old_bib = BIB_OUT.read_text() if BIB_OUT.exists() else ""
    new_bib = tmp_bib.read_text()
    if new_bib != old_bib:
        tmp_bib.replace(BIB_OUT)
        print("Updated", BIB_OUT)
    else:
        tmp_bib.unlink(missing_ok=True)
        print("No changes for", BIB_OUT)

if __name__ == "__main__":
    fetch_and_build()
