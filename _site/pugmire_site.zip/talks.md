---
layout: page
title: "Talks"
---

# Talks & Lectures

<!-- Leaflet CSS & JS -->
<link
  rel="stylesheet"
  href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<div id="mapid" style="height: 520px; margin: 1rem 0;"></div>

<script>
  const map = L.map('mapid', { worldCopyJump: true }).setView([20, 0], 2);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 10,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  const talks = {{ site.data.talks | jsonify }};
  talks.forEach(t => {
    const marker = L.marker([t.lat, t.lon]).addTo(map);
    const lines = [
      `<b>${t.title || ""}</b>`,
      t.date ? `${t.date}` : "",
      t.location ? `${t.location}` : "",
      t.link ? `<a href="${t.link}" target="_blank">details</a>` : ""
    ].filter(Boolean).join("<br>");
    marker.bindPopup(lines || "Talk");
  });
</script>

## List
{% for t in site.data.talks %}
- **{{ t.title }}** — {{ t.date }}{% if t.location %}, {{ t.location }}{% endif %}{% if t.link %} — [link]({{ t.link }}){% endif %}
{% endfor %}
