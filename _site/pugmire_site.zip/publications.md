---
layout: page
title: "Publications"
---

# Publications

{% assign pubs = site.data.publications | sort: "year" | reverse %}

## Journal Articles
{% assign journals = pubs | where: "type", "journal" %}
{% assign years = journals | map: "year" | uniq | sort | reverse %}
{% for y in years %}
### {{ y }}
{% for p in journals %}{% if p.year == y %}
- **{{ p.title }}**  
  {{ p.authors }}  
  *{{ p.venue }}*, {{ p.year }}{% if p.doi %}. DOI: {{ p.doi }}{% endif %}{% if p.url %}. [Link]({{ p.url }}){% endif %}
{% endif %}{% endfor %}
{% endfor %}

## Conference Papers
{% assign conferences = pubs | where: "type", "conference" %}
{% assign years = conferences | map: "year" | uniq | sort | reverse %}
{% for y in years %}
### {{ y }}
{% for p in conferences %}{% if p.year == y %}
- **{{ p.title }}**  
  {{ p.authors }}  
  *{{ p.venue }}*, {{ p.year }}{% if p.doi %}. DOI: {{ p.doi }}{% endif %}{% if p.url %}. [Link]({{ p.url }}){% endif %}
{% endif %}{% endfor %}
{% endfor %}

## Book Chapters
{% assign books = pubs | where: "type", "bookchapter" %}
{% assign years = books | map: "year" | uniq | sort | reverse %}
{% for y in years %}
### {{ y }}
{% for p in books %}{% if p.year == y %}
- **{{ p.title }}**  
  {{ p.authors }}  
  *{{ p.venue }}*, {{ p.year }}{% if p.doi %}. DOI: {{ p.doi }}{% endif %}{% if p.url %}. [Link]({{ p.url }}){% endif %}
{% endif %}{% endfor %}
{% endfor %}
